<?php
include('config.php');
$active_user = $_COOKIE['username'];

    //Sprawdzam do kogo nalezy apk
    // pobieranie zawartosci pliku                                        
    $status = file_get_contents($_GET['delete'].'/status.php');
    $status=explode('||',$status);
    $assignedUser=$status[0];
    $blocked=$status[1];
    

if(isset($_GET['delete']) and $_COOKIE['username']=$assignedUser){
$directory_to_remove = $_GET['delete'];

function deleteAll($str) {
    //It it's a file.
    if (is_file($str)) {
        //Attempt to delete it.
        return unlink($str);
    }
    //If it's a directory.
    elseif (is_dir($str)) {
        //Get a list of the files in this directory.
        $scan = glob(rtrim($str,'/').'/*');
        //Loop through the list of files.
        foreach($scan as $index=>$path) {
            //Call our recursive function.
            deleteAll($path);
        }
        //Remove the directory itself.
        return @rmdir($str);
    }
}
 
//call our function
deleteAll($directory_to_remove);
//generuje plik addons.xml
file_get_contents(''.$repository_domain.'/_'.$repo_id.'/create_addons_xml.php');

// ten plik generuje pliki addons.xml oraz  addons.xml.md5
file_get_contents(''.$repository_domain.'/_'.$repo_id.'/zip.php?zip-remove=1');
header("Location: addons.php");

}else{header("Location: addons.php");
}



?>
