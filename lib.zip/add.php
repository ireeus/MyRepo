<!DOCTYPE html>
<html lang="en">
<head>
  <title>Publish your addon</title>
<?php
include('lib/php/style.php');
include('config.php');
$active_user = $_COOKIE['username'];
if(isset($_COOKIE['username'])){$loginStatus = '<li ><a href="login.php"><font color="white">User: </font><font color="green">'.$active_user.'</font> - Logout</a></li>';}
elseif(!isset($_COOKIE['username'])){$loginStatus = '<li ><a href="login.php">Login</a></li>';}


?>

<style>/* Bordered form */
form {
  border: 3px solid #f1f1f1;
}

/* Full-width inputs */
input[type=text], input[type=password] {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}



/* Add a hover effect for buttons */
button:hover {
  opacity: 0.8;
}
/* Extra style for the cancel button (red) */
.accept {
  width: auto;
  padding: 10px 18px;
  background-color: #69C97A;
}
/* Center the avatar image inside this container */
.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

/* Avatar image */
img.avatar {
  width: 40%;
  border-radius: 50%;
}

/* Add padding to containers */
.container {
  padding: 16px;
}

/* The "Forgot password" text */
span.psw {
  float: right;
  padding-top: 16px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
    display: block;
    float: none;
  }
  .cancelbtn {
    width: 100%;
  }
}</style>
</head>
<body>


<div class="container-fluid">
  <div class="row content">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      
    <ul class="nav navbar-nav">
        <li ><a href="index.php">Home</a></li>
          <li ><a href="addons.php">Addons</a></li>
          <li class="active"><a href="">Publish addon</a></li>
            <?php echo $loginStatus;?>
    </ul>
  </div>
</nav>
</div><br><br><br><br>
<?php
////////////////////////////////////////////////////////////// 
       //przypisywanie zmiennych z $_POST
       // $provider = $_POST['provider'];
        //$addonName = $_POST['addonName'];
        //$email = $_POST['email'];
        //$description = $_POST['description'];
        //$license = $_POST['license'];
// Wykonywanie dzialanie jesli zaistnial $_POST['text']

if(isset($_POST['text']))
{

    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));


    //usowa rozszerzenie
    $fileName= basename($_FILES["fileToUpload"]["name"]);
    $fileNameNoExtension = preg_replace("/\.[^.]+$/", "", $fileName);


    sleep(1);

    // Check file size
    if ($_FILES["fileToUpload"]["size"] > 5000000000) 
        {
        echo '<div class="alert alert-danger">Sorry, your file is too large.</div>';
        $uploadOk = 0;
        }

    // Allow certain file formats
    if($imageFileType != "zip" ) {
        echo '<div class="alert alert-danger">Sorry, only zip files are allowed.</div>';
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) 
    {        echo '<div class="alert alert-danger">Sorry, your file was not uploaded.</div>';
        // if everything is ok, try to upload file
    } else 
    {
            if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) 
        {
 
       } 
    }

// sprawdzanie czy aplikacja do kogo nalezy

    // pobieranie zawartosci pliku                                        
    $status = file_get_contents('_'.$repo_id.'/'.$fileNameNoExtension.'/status.php');
    $status=explode('||',$status);
    $assignedUser=$status[0];
    $blocked=$status[1];

if($assignedUser==$_COOKIE['username'] or $assignedUser==''){
/////////////////////////////////////////////////////////////
//////wypakowywanie wymaganych plikow do dzialania repo//////
        $zip = new ZipArchive;
        if ($zip->open('uploads/'.$fileNameNoExtension.'.zip') === TRUE) {
            $zip->extractTo('_'.$repo_id.'/', array($fileNameNoExtension.'/addon.xml'));
            $zip->close();
            chmod("_'.$repo_id.'/".$fileNameNoExtension, 0775);
            echo '';
$string = file_get_contents('_'.$repo_id.'/'.$fileNameNoExtension.'/addon.xml');

//////////szukanie bledow w xml//////////////////////////
libxml_use_internal_errors(true);
$sxe = simplexml_load_string($string);
if ($sxe == false) {
    echo '<div class="alert alert-danger">Failed loading XML</div>';
    foreach(libxml_get_errors() as $error) {
echo '<div class="alert alert-danger">';
        echo "\t", $error->message;
echo'</div>';
unlink('_'.$repo_id.'/'.$fileNameNoExtension.'/addon.xml');
rmdir('_'.$repo_id.'/'.$fileNameNoExtension);
    }
}elseif($sxe == true){



////////////////////Kiedy wszystkie warunki sa spelnione ////////////////////////////////////

//////sprawdzanie danych aplikacji////////////////////////
            //wyciaganie versji z pliku xml
            $string = file_get_contents('_'.$repo_id.'/'.$fileNameNoExtension.'/addon.xml');
            $expStr=explode('?>',$string);
            $resultString=$expStr[1];
            $resultString1=explode('version="',$resultString);
            $resultString2=explode('"',$resultString1[1]);
            $newVersion=$resultString2[0];
           //wyciaganie nazwy folderu z pliku xml
            $resultString=$expStr[1];
            $resultString1=explode('<addon id="',$resultString);
            $resultString2=explode('"',$resultString1[1]);
            $fileNameNoExtension=$resultString2[0];
            //wyciaganie nazwy z pliku xml
            $resultString=$expStr[1];
            $resultString1=explode('name="',$resultString);
            $resultString2=explode('"',$resultString1[1]);
            $addonName=$resultString2[0];
            //wyciaganie wlasciciela z pliku xml
            $resultString=$expStr[1];
            $resultString1=explode('provider-name="',$resultString);
            $resultString2=explode('"',$resultString1[1]);
            $provider=$resultString2[0];
            //wyciaganie licencji z pliku xml
            $resultString=$expStr[1];
            $resultString1=explode('<license>',$resultString);
            $resultString2=explode('</license>',$resultString1[1]);
            $license=$resultString2[0];
            //wyciaganie maila z pliku xml
            $resultString=$expStr[1];
            $resultString1=explode('<email>',$resultString);
            $resultString2=explode('</email>',$resultString1[1]);
            $email=$resultString2[0];
            //wyciaganie typu z pliku xml
            $resultString=$expStr[1];
            $resultString1=explode('<provides>',$resultString);
            $resultString2=explode('</provides>',$resultString1[1]);
            $provides=$resultString2[0];
if($provides==''){$provides='Repository';}
            //wyciaganie opisu z pliku xml
            $resultString=$expStr[1];
            $resultString1=explode('<description lang="en_GB">',$resultString);
            $resultString2=explode('</description>',$resultString1[1]);
            $description=$resultString2[0];
            // obcinanie opisu do `50 znaków i na konicu ...
            $description = mb_strimwidth($description, 0, 150, '...');

  echo '<div class="alert alert-success">The <b>'. basename( $_FILES["fileToUpload"]["name"]). ' </b> ver. <b>'.  $newVersion.' </b>has been uploaded. </div>';


        $zip = new ZipArchive;
        if ($zip->open('uploads/'.$fileNameNoExtension.'.zip') === TRUE) {
            $zip->extractTo('_'.$repo_id.'/', array($fileNameNoExtension.'/resources/icon.png'));
            $zip->extractTo('_'.$repo_id.'/', array($fileNameNoExtension.'/resources/fanart.jpg'));
            $zip->close();
            chmod("_'.$repo_id.'/".$fileNameNoExtension, 0775);
            echo '';}
        $zip = new ZipArchive;
        if ($zip->open('uploads/'.$fileNameNoExtension.'.zip') === TRUE) {
            $zip->extractTo('_'.$repo_id.'/', array($fileNameNoExtension.'/icon.png'));
            $zip->extractTo('_'.$repo_id.'/', array($fileNameNoExtension.'/fanart.jpg'));
            $zip->close();
            chmod("_'.$repo_id.'/".$fileNameNoExtension, 0775);
            echo '';}

//////////////////////////////////////////////////////////////
///////////////kopiowanie zip do folderu//////////////////////
    $repoversion = file_get_contents('_'.$repo_id.'/repover.php');
    //$year = date('y')-19;
    //$month = date('n');
	
    include('config.php');
    $repoversion = $year.'.'.$month.'.'.$repoversion;
    //echo $repoversion;


//The location of the file that we want to copy.
$fileToCopy = 'uploads/'.$fileNameNoExtension.'.zip';
 
//The file path that we want to copy it to.
$destinationOfCopy = '_'.$repo_id.'/'.$fileNameNoExtension.'/'.$fileNameNoExtension.'-'.$newVersion.'.zip';
 $destinationchmod = '_'.$repo_id.'/'.$fileNameNoExtension.'/';
   chmod($destinationchmod, 0777);
//Copy the file using PHP's copy function.
$success = copy($fileToCopy, $destinationOfCopy);
 
//Check if the copy was successful.
if($success){
    //Print out a message.
   //echo $fileToCopy . ' was copied to ' . $destinationOfCopy;

}
//////////////////////////////////////////////////////////////



//////////////////////////////////////////////////////////////
        //tworzenie pliku index.php w folderze aplikacji
        $my_ver = '_'.$repo_id.'/'.$fileNameNoExtension.'/index.php';
        $handle = fopen($my_ver, 'w') or die('f537001');
        $data1 = '<?php
        header("Location: details.php");';
        fwrite($handle, $data1);
        //tworzenie pliku ver.php
        $my_ver = '_'.$repo_id.'/'.$fileNameNoExtension.'/ver.php';
        $handle = fopen($my_ver, 'w') or die('f537002');
        $data1 = '<?php
        $currentVersion = "'.$newVersion.'";';
        fwrite($handle, $data1);
   // pobieranie zawartosci pliku -jesli istnieje to pomijam zeby zachowac komentarze                                     
    $status = file_get_contents('_'.$repo_id.'/'.$fileNameNoExtension.'/reported.db');
if($status==''){
        //tworzenie pliku db.php
        $my_ver = '_'.$repo_id.'/'.$fileNameNoExtension.'/reported.db';
        //jesli plik nie istnieje  to zostanie utworzony
        // jesloi istnieje to pozostanie bez zmian 
        if(!file_exists($my_ver)){$handle = fopen($my_ver, 'w') or die('f537003');
        $data1 = '';
        fwrite($handle, $data1);}
}



   // pobieranie zawartosci pliku -jesli istnieje to pomijam zeby zachowac komentarze                                     
    $status = file_get_contents('_'.$repo_id.'/'.$fileNameNoExtension.'/db.html');
if($status==''){
        //tworzenie pliku db.php
        $my_ver = '_'.$repo_id.'/'.$fileNameNoExtension.'/db.html';
        //jesli plik nie istnieje  to zostanie utworzony
        // jesloi istnieje to pozostanie bez zmian 
        if(!file_exists($my_ver)){$handle = fopen($my_ver, 'w') or die('f537004');
        $data1 = '';
        fwrite($handle, $data1);}
}

//Sprawdzam czy aplikacja nie jest zablokowana-jesli jest to pomijam plik
    // pobieranie zawartosci pliku                                        
    $status = file_get_contents('_'.$repo_id.'/'.$fileNameNoExtension.'/status.php');
    $status=explode('||',$status);
    $assignedUser=$status[0];
    $blocked=$status[1];

if($blocked!='blocked
'){
        //tworzenie pliku status.php
        $my_file = '_'.$repo_id.'/'.$fileNameNoExtension.'/status.php';
        $handle = fopen($my_file, 'w') or die('f537005');
        $data1 = $active_user.'||';
        fwrite($handle, $data1);        
}
//////////////////////////////////////////////////////////////
        //tworzenie pliku zawierajaceg informacje o aplikacji info.html
        $my_file = '_'.$repo_id.'/'.$fileNameNoExtension.'/info.html';
        $time = date("Y-m-d h:i:s");
        $handle = fopen($my_file, 'w') or die('f537006');
        $data1 = '
        <h4>'.$addonName.'<small> ('.$provides.')</small></h4>
        <small><font color="grey">Provided by: </font><font color="purple"><i>'.$provider.'</i></font></small><br>
        <small><font color="grey">e-mail: </font><font color="black"><i>'.$email.'</i></font></small><br>
        <small><font color="grey">Timestamp: </font><font color="blue"><i>'.$time.'</i></font></small><br>
        <small><font color="grey">License: </font><font color="green"><i>'.$license.'</i></font></small><br>
        <p><small>'.$description.'</small></p>';
        fwrite($handle, $data1);
//////////////////////////////////////////////////////////////
        //tworzenie pliku wykonawczego glosowania "vote.php"
        $my_file = '_'.$repo_id.'/'.$fileNameNoExtension.'/vote.php';
        $handle = fopen($my_file, 'w') or die('f537007');
        $data1 = '<?php
        if(isset($_POST["score"]) and ($_POST["score"] != "")){
        $score = $_POST["score"];
        echo $score;
        //tutaj trzeba zapisac wartosc do pliku
			        $dataString = $score."
			        ";

			        $fWrite = fopen("vote.txt","at");


			        $wrote = fwrite($fWrite, $dataString);
			        fclose($fWrite);
        header("Location: details.php");
       
        }';
        fwrite($handle, $data1);
        //tworzenie pliku wykonawczego glosowania "details.php"
        $my_ver = '_'.$repo_id.'/'.$fileNameNoExtension.'/details.php';
        $handle = fopen($my_ver, 'w') or die('f537008');
        $data1 = '<?php
        include("../details.php");';
        fwrite($handle, $data1);

        //tworzenie pliku  glosowania "vote.txt"
        $my_ver = '_'.$repo_id.'/'.$fileNameNoExtension.'/vote.txt';
        $handle = fopen($my_ver, 'w') or die('f537008a');
        $data1 = '';
        fwrite($handle, $data1);

// wykonuje działania zawarte w pliku zip.php
$repoversion = file_get_contents($repository_domain.'/_'.$repo_id.'/zip.php');
       
        //generuje plik addons.xml
file_get_contents($repository_domain.'/_'.$repo_id.'/create_addons_xml.php');
//////////////////////////////////////////////////////////////

////////tworzenie 4 plikow za ostatnio dodanymi///////////

    //poberam dane z pliku recent 1
        $recent = file_get_contents('lib/php/recent.php');
        $recent1 = file_get_contents('lib/php/recent1.php');
        $recent2 = file_get_contents('lib/php/recent2.php');
        $recent3 = file_get_contents('lib/php/recent3.php');

        if($recent===$fileNameNoExtensionor or $recent1===$fileNameNoExtension or $recent2===$fileNameNoExtension or $recent3===$fileNameNoExtension){echo"";}else{

    //tworzenie pliku recent.php
        $my_ver = 'lib/php/recent4.php';
        $handle = fopen($my_ver, 'w') or die('f537009');
        $data = $recent3;
        fwrite($handle, $data);

    //tworzenie pliku recent.php
        $my_ver = 'lib/php/recent3.php';
        $handle = fopen($my_ver, 'w') or die('f537010');
        $data = $recent2;
        fwrite($handle, $data);

    //tworzenie pliku recent.php
        $my_ver = 'lib/php/recent2.php';
        $handle = fopen($my_ver, 'w') or die('f537011');
        $data = $recent1;
        fwrite($handle, $data);

    //tworzenie pliku recent.php
        $my_ver = 'lib/php/recent1.php';
        $handle = fopen($my_ver, 'w') or die('f537012');
        $data = $recent;
        fwrite($handle, $data);


    //tworzenie pliku recent1.php
        $my_ver = 'lib/php/recent.php';
        $handle = fopen($my_ver, 'w') or die('f537013');
        $data = $fileNameNoExtension;
        fwrite($handle, $data);
}

    }elseif($currentVersion == '' or $newVersion=='' or $currentVersion and $newVersion==''){echo'';}
elseif($newVersion = $currentVersion){echo'<div class="alert alert-danger">Version of your addon needs to be greater than the one that already exist</div>';
} 
}
}else {echo'<div class="alert alert-warning">this package belongs to someone else</div>';}
}
$username =$active_user;
if($username!=''){
echo'


<br><br>
            
By uploading the file you agree to our terms:<br>

<br><br>
<button data-toggle="collapse" data-target="#demo">Terms And Contitions</button>

<div id="demo" class="collapse">
<small>
';

include('terms.php');
echo'


</div>
</small><br><br>
             <form action="" method="post" enctype="multipart/form-data">  <div style="margin-left: 10px; width: 400px"  > Select package to upload:<br><br>
                <input type="file" class="button" name="fileToUpload" id="fileToUpload">
                <input type="hidden" name="text" >
            <br>
                <input type="submit" class="button" value="Upload package" name="submit">
            </form><br><br><br><br><br><br></div>
';
}
?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
<div>
<br><br>
<footer class="container-fluid">
  <p><?php echo$repo_name;?></p>
</footer>

</body>
</html>















