<?php
//////////////////////////////////Repo config//////////////////////////////////////////////////////////////
// switching off the errors
ini_set("display_errors","off");

//Repository adddress - forward slash on the end
$repository_domain = "http://cloudrepo.5v.pl";

// Repo id - it is used as repo packages folder
$repo_id="cloudrepo";

//Repo name displayed in kodi
$repo_name="CloudRepo" ;

//Repo summary
$repo_summary ="The first repository with legal addons managed by you.";

// Nname of the repo owner
$repo_provider_name="Ireneusz Wójcik";

//Description of the repo 
$repo_description = "";

//////////////////////////////////////Do not change below///////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////////////

//Repository details
$addon_header_1='    <addon id="cloudrepo" name="'.$repo_name.'" version="';


$addon_header_2='" provider-name="'.$repo_provider_name.'">
        <requires>
            <import addon="xbmc.addon" version="12.0.0"/>
        </requires>
        <extension point="xbmc.addon.repository" name="'.$repo_name.'">
            <info compressed="false">'.$repository_domain .'/_'.$repo_id.'/addons.xml</info>
            <checksum>'.$repository_domain .'/_'.$repo_id.'/addons.xml.md5</checksum>
            <datadir zip="true">'.$repository_domain .'/_'.$repo_id.'/</datadir>
            <hashes>false</hashes>
        </extension>
        <extension point="xbmc.addon.metadata">
            <summary>'.$repo_summary.'</summary>
            <description>'.$repo_description.'</description>
            <platform>all</platform>
    </extension>
</addon>';
/////////////////////////////////////////////////////



// first two numbers of the repository version
$year = "0";//date('y')-19;
$month = "0";//date('n');