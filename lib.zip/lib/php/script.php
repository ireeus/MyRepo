<?php
$dirname = dirname($_SERVER['PHP_SELF']);
$weblink = "http://$_SERVER[HTTP_HOST]$dirname";
$weblink=$weblink.'/';
?>
