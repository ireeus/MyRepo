<?php 
include('config.php');
include('lib/php/script.php');
include('_'.$repo_id.'/index.php');
//$string = file_get_contents($weblink.'_cloudrepo/index.php');
echo $string;
