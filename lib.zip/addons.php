<!DOCTYPE html>
<html lang="en">
<head>
  <title>Addons</title>
<?php include('lib/php/style.php');
include('config.php');
$active_user = $_COOKIE['username'];
if(isset($_COOKIE['username'])){$loginStatus = '<li ><a href="login.php"><font color="white">User: </font><font color="green">'.$active_user.'</font> - Logout</a></li>';}
elseif(!isset($_COOKIE['username'])){$loginStatus = '<li ><a href="login.php">Login</a></li>';}
?>

<style>
#myInput {
  /*background-image: url('../lib/img/searchicon.png'); /* Add a search icon to input */
  background-position: 10px 12px; /* Position the search icon */
  background-repeat: no-repeat; /* Do not repeat the icon image */
  width: 100%; /* Full-width */
  font-size: 18px; /* Increase font-size */
  padding: 12px 20px 12px 40px; /* Add some padding */
  border: 1px solid #ddd; /* Add a grey border */
  margin-bottom: 1px; /* Add some space below the input */
}

#myUL {
  /* Remove default list styling */
  list-style-type: none;
  padding: 0;
  margin: 0;
}

#myUL li a {
  border: 1px solid #ddd; /* Add a border to all links */
  margin-top: -2px; /* Prevent double borders */
  background-color: #f6f6f6; /* Grey background color */
  padding: 8px; /* Add some padding */
  text-decoration: none; /* Remove default text underline */
  font-size: 14px; /* Increase the font-size */
  color: black; /* Add a black text color */
  display: block; /* Make it into a block element to fill the whole list */
}
.recent {
  border: 1px solid #ddd; /* Add a border to all links */
  margin-top: -2px; /* Prevent double borders */
  background-color: #f6f6f6; /* Grey background color */
  padding: 8px; /* Add some padding */
  text-decoration: none; /* Remove default text underline */
  font-size: 14px; /* Increase the font-size */
  color: black; /* Add a black text color */
  display: block; /* Make it into a block element to fill the whole list */
}

#myUL li a:hover:not(.header) {
  background-color: #eee; /* Add a hover effect to all links, except for headers */
}
.checkmark {


  height: 10px;
  width: 10px;
  background-color: #eee;
  border-radius: 50%;
}
 </style>
<script>
function myFunction() {
  // Declare variables
  var input, filter, ul, li, a, i, txtValue;
  input = document.getElementById('myInput');
  filter = input.value.toUpperCase();
  ul = document.getElementById("myUL");
  li = ul.getElementsByTagName('li');

  // Loop through all list items, and hide those who don't match the search query
  for (i = 0; i < li.length; i++) {
    a = li[i].getElementsByTagName("a")[0];
    txtValue = a.textContent || a.innerText;
    if (txtValue.toUpperCase().indexOf(filter) > -1) {
      li[i].style.display = "";
    } else {
      li[i].style.display = "none";
    }
  }
}
</script>
</head>
<body>


<div class="container-fluid">
  <div class="row content">

<nav class="navbar navbar-inverse navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span> 
      </button>

    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      
    <ul class="nav navbar-nav">
        <li ><a href="index.php">Home</a></li>
          <li class="active"><a href="">Addons</a></li>
          <li ><a href="add.php#">Publish addon</a></li>
            <?php echo $loginStatus;?>
    </ul>
  </div>
</nav>
</div>
<div style="margin-left: 10px" >
 <br><br><br>
<a calass="recent">
<div class="container">
  <div class="row">
    <div class="col-sm-2"><br><i><b>Recent uploads:</b></i></div>


<?php
//*////////recent.php ////////////////////
$location = file_get_contents('lib/php/recent.php'); 
$link = '_'.$repo_id.'/'.$location.'/details.php'; 
$icon = '_'.$repo_id.'/'.$location.'/icon.png'; 
$iconr = '_'.$repo_id.'/'.$location.'/resources/icon.png'; 
if(file_exists($icon)){$icon='_'.$repo_id.'/'.$location.'/icon.png'; $check='1';} 
elseif(file_exists($iconr)){$icon='_'.$repo_id.'/'.$location.'/resources/icon.png';$check='2';}else{$check='0';}
if($check<1){
$newVersion='';
$link ='';
$icon='lib/img/missing.jpg'; }
else{
//wyciaganie tytulu z pliku xml
$string = file_get_contents('_'.$repo_id.'/'.$location.'/addon.xml');
$expStr=explode('?>',$string);
$resultString=$expStr[1];
$resultString1=explode('name="',$resultString);
$resultString2=explode('"',$resultString1[1]);
$newVersion=$resultString2[0]; 
$newVersion = mb_strimwidth($newVersion, 0, 10, '...');
}

/////////recent1.php ////////////////////
$location1 = file_get_contents('lib/php/recent1.php'); 
$link1 = '_'.$repo_id.'/'.$location1.'/details.php'; 
$icon1 = '_'.$repo_id.'/'.$location1.'/icon.png'; 
$iconr1 = '_'.$repo_id.'/'.$location1.'/resources/icon.png'; 
if(file_exists($icon1)){$icon1='_'.$repo_id.'/'.$location1.'/icon.png'; $check1='1';} 
elseif(file_exists($iconr1)){$icon1='_'.$repo_id.'/'.$location1.'/resources/icon.png';$check1='2';}else{$check1='0';}
if($check1<1){
$newVersion1='';
$link1 ='';
$icon1='lib/img/missing.jpg'; }
else{
//wyciaganie tytulu z pliku xml
$string1 = file_get_contents('_'.$repo_id.'/'.$location1.'/addon.xml');
$expStr=explode('?>',$string1);
$resultString=$expStr[1];
$resultString1=explode('name="',$resultString);
$resultString2=explode('"',$resultString1[1]);
$newVersion1=$resultString2[0]; 
$newVersion1 = mb_strimwidth($newVersion1, 0, 10, '...');
}

/////////recent2.php ////////////////////
$location2 = file_get_contents('lib/php/recent2.php'); 
$link2 = '_'.$repo_id.'/'.$location2.'/details.php'; 
$icon2 = '_'.$repo_id.'/'.$location2.'/icon.png'; 
$iconr2 = '_'.$repo_id.'/'.$location2.'/resources/icon.png'; 
if(file_exists($icon2)){$icon2='_'.$repo_id.'/'.$location2.'/icon.png'; $check2='1';} 
elseif(file_exists($iconr2)){$icon2='_'.$repo_id.'/'.$location2.'/resources/icon.png';$check2='2';}else{$check2='0';}
if($check2<1){
$newVersion2='';
$link2 ='';
$icon2='lib/img/missing.jpg'; }
else{
//wyciaganie tytulu z pliku xml
$string2 = file_get_contents('_'.$repo_id.'/'.$location2.'/addon.xml');
$expStr=explode('?>',$string2);
$resultString=$expStr[1];
$resultString1=explode('name="',$resultString);
$resultString2=explode('"',$resultString1[1]);
$newVersion2=$resultString2[0]; 
$newVersion2 = mb_strimwidth($newVersion2, 0, 10, '...');
}
/////////recent3.php ////////////////////
$location3 = file_get_contents('lib/php/recent3.php'); 
$link3 = '_'.$repo_id.'/'.$location3.'/details.php'; 
$icon3 = '_'.$repo_id.'/'.$location3.'/icon.png'; 
$iconr3 = '_'.$repo_id.'/'.$location3.'/resources/icon.png'; 
if(file_exists($icon3)){$icon3='_'.$repo_id.'/'.$location3.'/icon.png'; $check3='1';} 
elseif(file_exists($iconr3)){$icon3='_'.$repo_id.'/'.$location3.'/resources/icon.png';$check3='2';}else{$check3='0';}
if($check3<1){
$newVersion3='';
$link3 ='';
$icon3='lib/img/missing.jpg'; }
else{
//wyciaganie tytulu z pliku xml
$string3 = file_get_contents('_'.$repo_id.'/'.$location3.'/addon.xml');
$expStr=explode('?>',$string3);
$resultString=$expStr[1];
$resultString1=explode('name="',$resultString);
$resultString2=explode('"',$resultString1[1]);
$newVersion3=$resultString2[0];  
$newVersion3 = mb_strimwidth($newVersion3, 0, 10, '...');
}
?>
<div class="col-sm-2">
    <center>
        <a class="recent " href="<?php echo$link ;?>"><img width="40%" src="<?php echo $icon;?>"><br><small><?php echo$newVersion;?></small></a>
    </center>
</div>
<div class="col-sm-2">
    <center>
        <a class="recent hidden-xs" href="<?php echo$link1 ;?>"><img width="40%" src="<?php echo $icon1;?>"><br><small><?php echo$newVersion1;?></small></a>
    </center>
</div>
<div class="col-sm-2">
    <center>
        <a class="recent hidden-xs" href="<?php echo$link2 ;?>"><img width="40%" src="<?php echo $icon2;?>"><br><small><?php echo$newVersion2;?></small></a>
    </center>
</div>
<div class="col-sm-2 hidden-xs">
    <center>
        <a class="recent" href="<?php echo$link3 ;?>"><img width="40%" src="<?php echo $icon3;?>"><br><small><?php echo$newVersion3;?></small></a>
    </center>
</div>



</div>
</a>

<br><input type="text" id="myInput" onkeyup="myFunction()" placeholder="Search for addons..">

  <ul id="myUL">

<?php


//wyswietlanie zawartosci folderu

$Dir = '_'.$repo_id.'/';
$dirs = array_filter(glob($Dir .'*'), 'is_dir');

while (list($key, $val) = each($dirs))
  {



                    //echo $blocked;

    if($val!='_'.$repo_id.'/'.$repo_id.''){
                    // pobieranie zawartosci pliku                                        
                    $status = file_get_contents($val.'/status.php');
                    $status=explode('||',$status);
                    $assignedUser=$status[0];
                    $blocked=$status[1];



                    // pobieranie zawartosci pliku
                    $string = file_get_contents($val.'/info.html');

//echo $val;

                    // kalkulacja statystyk
                    $file = file_get_contents($val.'/vote.txt');

                    $a1=substr_count($file, '1'); 
                    $a2=substr_count($file, '2');
                    $a3=substr_count($file, '3');
                    $a4=substr_count($file, '4');
                    $a5=substr_count($file, '5');

                    $total=$a1+$a2+$a3+$a4+$a5;
if ($total == '' or $total==''){$score = '0';}
if ($total != '' or $total!=''){$score=($a1*1+$a2*2+$a3*3+$a4*4+$a5*5)/$total;}
                    
                    if($score=='NAN'){$score='0';}

                    if ($file=='') {
                          $score='0';
                        }
                    if($a1>0){$a1=$a1/$total*10;}
                    if($a2>0){$a2=$a2/$total*10;}
                    if($a3>0){$a3=$a3/$total*10;}
                    if($a4>0){$a4=$a4/$total*10;}
                    if($a5>0){$a5=$a5/$total*10;}

                    $a1=round($a1, '0'); 
                    $a2=round($a2, '0');
                    $a3=round($a3, '0');
                    $a4=round($a4, '0');
                    $a5=round($a5, '0');
                    $score=round($score, '1');
                    if($score=='0'){$score='<font color="#000000"><b>'.$score.'</b></font>';}
                    if($score<='1'){$score='<font color="#f4424b"><b>'.$score.'</b></font>';}
                    if($score<='2'){$score='<font color="#f442e8"><b>'.$score.'</b></font>';}
                    if($score<='3'){$score='<font color="#8f42f4"><b>'.$score.'</b></font>';}
                    if($score<='4'){$score='<font color="#42a7f4"><b>'.$score.'</b></font>';}
                    if($score<='5'){$score='<font color="green"><b>'.$score.'</b></font>';}
                    //searching for icon file
                    $iconr =$val.'/resources/icon.png';
                    $iconn=$val.'/icon.png';
                    include($val.'/ver.php');


                    if (!file_exists($iconr)) {$icon='icon.png';} 
                    if(!file_exists($iconn)) {$icon='resources/icon.png';}
                    if((!file_exists($iconn)) && (!file_exists($iconr))){ $icon='../../lib/img/missing.jpg';} 


                // pokazywanie dla wlascicieli                    
if($blocked == 'blocked
' and $assignedUser ==  $_COOKIE['username']){$status ="0";}


                // blokowanie dla zalogowanych
                    if($blocked == 'blocked
' and $_COOKIE['username'] != $assignedUser){$status ="1";}
/*

                // blokowanie dla nie zalogowanych
                    elseif($blocked == 'blocked
' and $active_user ==''){$status ="1";}
*/




                    if($status!="1"){

                    //////Content///////
                    echo'<li ><a >
                    <table>
                      <tr>
                        <th>                <table style="margin: 1px">   <tr>
                                      <tr>
                                        <td><center><img src="lib/img/bar/'.$a1.'.png" width="5"></center></td>
                                        <td><center><img src="lib/img/bar/'.$a2.'.png" width="5"></center></td>
                                        <td><center><img src="lib/img/bar/'.$a3.'.png" width="5"></center></td>
                                        <td><center><img src="lib/img/bar/'.$a4.'.png" width="5"></center></td>
                                        <td><center><img src="lib/img/bar/'.$a5.'.png" width="5"></center></td>
                                      </tr>
                                      </tr>

                                      <tr >
                                    <form action="'.$val.'/vote.php" method="post">
                                        <td><input type="radio" class="checkmark" name="score" required value="1"> </td>
                                        <td><input type="radio" class="checkmark" name="score" required value="2"> </td>
                                        <td><input type="radio" class="checkmark" name="score" required value="3"> </td>
                                        <td><input type="radio" class="checkmark" name="score" required value="4"> </td>
                                        <td><input type="radio" class="checkmark" name="score" required value="5"> </td>

                                      </tr>  
                                         <tr   >
                                        <td ><small>1<small></td>
                                        <td><small>2<small></td>
                                        <td><small>3<small></td>
                                        <td><small>4<small></td>
                                        <td><small>5<small></td>
                                      </tr>
                                      <tr>
                                        <td colspan="5"><center><button class="button1">Vote ('.$total.')</button><br>
                                  
                                    <center><font color="grey" size="1">Score:</font><font size="2">

                                    '.$score.'</font>
                                    <small>
                                    </small></center></td>
                                      </tr>
                                    </form>
                                    </table></th>
                        <th>
                        <center>
            <a style="margin-left: 3px; margin-top: -1px;  margin-right: 3px; margin-bottom: -9px"  href="'.$val.'/details.php"><img   style="margin-right: -6px; margin-left: -6px; margin-top: -6px; margin-bottom: -2px" src="'.$val.'/'.$icon.'" width="75"><br>
                <font color="grey"  size="1">Ver:</font><font  color="orange" size="1"> '.$currentVersion.'</font>

                   </a><br>';
 // ukrywanie przycisku delete dla wlascicieli                    
if($assignedUser !=  $_COOKIE['username'] and $_COOKIE['username']!=''){
echo'
<form action="'.$val.'/details.php?report=1" method="post"><center><input type="hidden" name="report" value="'.$_COOKIE['username'].'"><button class="button2">Report</button></center></form>'; }
if($_COOKIE['username']== ''){echo'
<form action="login.php" method="post"><center><input type="hidden" name="report" value="'.$_COOKIE['username'].'"><button class="button2">Report</button></center></form>';}

                // pokazywanie przycisku delete dla wlascicieli                    
if($assignedUser ==  $_COOKIE['username'] and $_COOKIE['username']!= ''){echo'

<a  style="margin-left: 3px; margin-top: -1px;  margin-right: 3px; margin-bottom: -9px"  href="delete.php?delete='.$val.'">


<button class="button2">Delete</button>






</a>';}
if($assignedUser !=  $_COOKIE['username']){}


                            echo'
                        <center></th>
                        <th  >'.$string.'</th>
                      </tr>
                    </table></a>
                    </li>

                    '; }}
            

 }



?>
</ul>

 </table>
</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<br><br><br><br><br><br><br><br>
<footer class="container-fluid">
  <p><?php echo$repo_name; ?></p>
</footer>

</body>
</html>















